-- Criar banco de dados db_Biblioteca
CREATE DATABASE db_StockData1 ON PRIMARY
(NAME = db_StockData1,
FILENAME = 'C:\SQL\db_StockData1.mdf',
SIZE = 6MB,
MAXSIZE = 15MB,
FILEGROWTH = 10%)
LOG ON (
NAME = db_stockData1_log,
FILENAME = 'C:\SQL\db_StockData1_log.ldf',
SIZE = 1MB, FILEGROWTH = 1MB)
GO

--Alterar o banco de dados em uso
USE db_StockData1
GO

-- Criar a tabela de estados
CREATE TABLE tbl_estados(
ID_Estado TINYINT PRIMARY KEY IDENTITY(1,1),
Estado CHAR(2) NOT NULL
);

--Adicionando as siglas dos Estados
INSERT INTO tbl_estados (Estado)
VALUES
('AC'), ('AL'), ('AM'), ('AP'), ('BA'), ('CE'), ('DF'), ('ES'), ('GO'), ('MA'), ('MT'), ('MS'), ('MG'), ('PA'), ('PB'), ('PR'),
('PE'), ('PI'), ('RJ'), ('RN'), ('RS'), ('RO'), ('RR'), ('SC'), ('SP'), ('SE'), ('TO');

--Criar tabela de Loja
CREATE TABLE tbl_loja(
CNPJ CHAR(14) PRIMARY KEY,
Nome_Loja  VARCHAR(30) NOT NULL,
imagem VARCHAR(200) NOT NULL,
senha VARCHAR(255) NOT NULL,
Rua VARCHAR(30) NOT NULL,
Numero SMALLINT NOT NULL,
Bairro VARCHAR(30) NOT NULL,
Complemento VARCHAR(20),
Cep VARCHAR(11) NOT NULL,
Email VARCHAR(50) NOT NULL,
Celular VARCHAR(15) NOT NULL,
Telefone VARCHAR(15) NOT NULL,
ID_Estado TINYINT NOT NULL,
CONSTRAINT fk_ID_Estado FOREIGN KEY (ID_Estado)
	REFERENCES tbl_estados (ID_Estado) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

--Criando Tabela de funcionario
CREATE TABLE tbl_funcionario (
CPF CHAR(11) PRIMARY KEY,
Nome VARCHAR(50) NOT NULL,
Sobrenome VARCHAR(60) NOT NULL,
--Imagem VARCHAR(200),
--Senha VARCHAR(255) NOT NULL,
Email VARCHAR(50) NOT NULL,
Celular VARCHAR(15) NOT NULL,
CNPJ_Loja CHAR(14)
CONSTRAINT fk_CNPJ_Loja FOREIGN KEY (CNPJ_Loja)
	REFERENCES tbl_loja (CNPJ) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

--Criando Tabela de Produto
CREATE TABLE tbl_produto(
ID_Produto SMALLINT PRIMARY KEY IDENTITY(1,1),
Nome_Produto VARCHAR(30) NOT NULL,
Genero VARCHAR(20) NOT NULL,
Quantidade SMALLINT NOT NULL,
Preco MONEY NOT NULL,
Imagem VARCHAR(200),
CNPJ_Prod CHAR(14)
CONSTRAINT fk_CNPJ_Prod FOREIGN KEY (CNPJ_Prod)
	REFERENCES tbl_loja (CNPJ) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

--Criando Tabela de fornecedor
CREATE TABLE tbl_fornecedor(
CNPJ CHAR(14) PRIMARY KEY,
Nome_Social VARCHAR(100) NOT NULL,
Imagem VARCHAR(200),
Email VARCHAR(50) NOT NULL,
Celular VARCHAR(15) NOT NULL,
Telefone VARCHAR(20) NOT NULL,
Rua VARCHAR(30) NOT NULL,
Numero SMALLINT NOT NULL,
Bairro VARCHAR(30) NOT NULL,
Complemento VARCHAR(20),
Cep VARCHAR(11) NOT NULL,
ID_EstadoForn TINYINT NOT NULL,
CONSTRAINT fk_ID_EstadoForn FOREIGN KEY (ID_EstadoForn)
	REFERENCES tbl_estados (ID_Estado) ON DELETE CASCADE ON UPDATE CASCADE
);
GO

-- Criar tabela de Relacionamento Fornecedor-Loja
CREATE TABLE tbl_fornecedor_loja(
CNPJ_fornecedor CHAR(14),
CNPJ_loja CHAR(14),
CONSTRAINT pk_cnpjs PRIMARY KEY (CNPJ_fornecedor, CNPJ_loja),
CONSTRAINT fk_CNPJ_fornecedor FOREIGN KEY (CNPJ_fornecedor)
	REFERENCES tbl_fornecedor (CNPJ) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_CNPJ_loja FOREIGN KEY (CNPJ_loja)
	REFERENCES tbl_loja (CNPJ) ON DELETE CASCADE ON UPDATE CASCADE
);GO

ALTER TABLE tbl_fornecedor
ALTER COLUMN Complemento VARCHAR(20);
ALTER TABLE tbl_loja
ALTER COLUMN Complemento VARCHAR(20);

ALTER TABLE tbl_funcionario
DROP COLUMN Senha;

SELECT * FROM tbl_loja;
SELECT * FROM tbl_fornecedor;
SELECT * FROM tbl_funcionario;
SELECT MAX(ID_Produto) ID_Produto FROM tbl_produto;

/*
INSERT INTO tbl_fornecedor(CNPJ, Nome_Social, Imagem, Rua, Numero, Bairro, Complemento, Cep, Email, Celular, Telefone, ID_EstadoForn)
VALUES ('mtxtCNPJ.Text.Replace("-", "").Replace("_", "").Replace(".", "").Replace("/", "") + "','" + txtNomeSocial.Text + "','" + caminhoImagem + "','" + txtRua.Text + "'," + txtNumero.Text + ",'" + txtBairro.Text + "','" + txtComplemento.Text + "','" + txtCep.Text + "','" + txtEmail.Text + "','" + txtCelular.Text + "','" + txtTelefone.Text + "'," + ID_Estado + ")";

INSERT INTO tbl_funcionario(CPF, Nome, Sobrenome, Email, Celular, Telefone, CNPJ_Loja);*/

