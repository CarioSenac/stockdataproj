/*JavaScript para apagar oque estiver escrito na TextBox de nomeUser*/
document.addEventListener('DOMContentLoaded', () => {
    const btnFisica = document.getElementById('btnFisica');
    const btnJuridica = document.getElementById('btnJuridica');
    const nomeUsuario = document.getElementById('nome-usuario');

    btnFisica.addEventListener('click', () => {
        nomeUsuario.disabled = false;
        nomeUsuario.placeholder = "Nome de usuário";
        nomeUsuario.required = true;
    });

    btnJuridica.addEventListener('click', () => {
        nomeUsuario.disabled = true;
        nomeUsuario.placeholder = "Nome de usuário (não necessário para PJ)";
        nomeUsuario.required = false;
        nomeUsuario.value = ""; // Limpa o campo de texto
    });
});

/*JavaScript para saber qual foi a opção escolhida*/
function selecionarPessoa(tipo) {
    // const btnEntrar = document.getElementById('btnEntrar');
    const juridicaBtn = document.getElementById('btnJuridica');
    const fisicaBtn = document.getElementById('btnFisica');

    // Mudar a cor do botão de acordo com a escolha // Mudar a cor do botão "Entrar" de acordo com a escolha
    if (tipo === 'juridica') {
        // btnEntrar.style.backgroundColor = 'green';
        juridicaBtn.style.backgroundColor = '#00FF43'; // Pessoa Jurídica botão fica verde // Pessoa Jurídica botão fica verde
        fisicaBtn.style.backgroundColor = '#273D31'; // Volta à cor original // Voltar cor original para o outro botão
    } else if (tipo === 'fisica') {
        // btnEntrar.style.backgroundColor = 'green';
        fisicaBtn.style.backgroundColor = '#00FF43'; // Pessoa Física botão fica verde // Pessoa Física botão fica verde
        juridicaBtn.style.backgroundColor = '#273D31'; // Volta à cor original // Voltar cor original para o outro botão
    }
}