﻿namespace ProjetoUC12_StockDATA
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAjuda = new System.Windows.Forms.Button();
            this.btnRegistrese = new System.Windows.Forms.Button();
            this.btnEntrar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAjuda
            // 
            this.btnAjuda.FlatAppearance.BorderSize = 0;
            this.btnAjuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAjuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAjuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAjuda.Location = new System.Drawing.Point(735, 373);
            this.btnAjuda.Name = "btnAjuda";
            this.btnAjuda.Size = new System.Drawing.Size(113, 66);
            this.btnAjuda.TabIndex = 4;
            this.btnAjuda.Text = "Ajuda";
            this.btnAjuda.UseVisualStyleBackColor = true;
            // 
            // btnRegistrese
            // 
            this.btnRegistrese.BackColor = System.Drawing.Color.Transparent;
            this.btnRegistrese.BackgroundImage = global::ProjetoUC12_StockDATA.Properties.Resources.stocksdata_Registrese;
            this.btnRegistrese.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRegistrese.FlatAppearance.BorderSize = 0;
            this.btnRegistrese.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRegistrese.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnRegistrese.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrese.Location = new System.Drawing.Point(321, 388);
            this.btnRegistrese.Name = "btnRegistrese";
            this.btnRegistrese.Size = new System.Drawing.Size(355, 51);
            this.btnRegistrese.TabIndex = 3;
            this.btnRegistrese.Text = "Registre-se";
            this.btnRegistrese.UseVisualStyleBackColor = false;
            this.btnRegistrese.Click += new System.EventHandler(this.btnRegistrese_Click);
            // 
            // btnEntrar
            // 
            this.btnEntrar.BackColor = System.Drawing.Color.Transparent;
            this.btnEntrar.BackgroundImage = global::ProjetoUC12_StockDATA.Properties.Resources.stocksdata;
            this.btnEntrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEntrar.FlatAppearance.BorderSize = 0;
            this.btnEntrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEntrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrar.ForeColor = System.Drawing.Color.Transparent;
            this.btnEntrar.Location = new System.Drawing.Point(265, 260);
            this.btnEntrar.Name = "btnEntrar";
            this.btnEntrar.Size = new System.Drawing.Size(464, 122);
            this.btnEntrar.TabIndex = 2;
            this.btnEntrar.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(372, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(270, 227);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.ClientSize = new System.Drawing.Size(1082, 590);
            this.Controls.Add(this.btnAjuda);
            this.Controls.Add(this.btnRegistrese);
            this.Controls.Add(this.btnEntrar);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Menu Inicial";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnEntrar;
        private System.Windows.Forms.Button btnRegistrese;
        private System.Windows.Forms.Button btnAjuda;
    }
}

