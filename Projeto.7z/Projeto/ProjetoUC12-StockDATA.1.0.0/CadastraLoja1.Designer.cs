﻿namespace ProjetoUC12_StockDATA
{
    partial class CadastraLoja1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picLoja = new System.Windows.Forms.PictureBox();
            this.btnSelecImagem = new System.Windows.Forms.Button();
            this.btnCadastra = new System.Windows.Forms.Button();
            this.txtCep = new System.Windows.Forms.TextBox();
            this.txtComplemento = new System.Windows.Forms.TextBox();
            this.txtRepSenha = new System.Windows.Forms.TextBox();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.txtNomeLoja = new System.Windows.Forms.TextBox();
            this.txtRua = new System.Windows.Forms.TextBox();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblimagem = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblCelular = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblCep = new System.Windows.Forms.Label();
            this.lblComplemento = new System.Windows.Forms.Label();
            this.lblBairro = new System.Windows.Forms.Label();
            this.lblNum = new System.Windows.Forms.Label();
            this.lblRua = new System.Windows.Forms.Label();
            this.lblRepitaSenha = new System.Windows.Forms.Label();
            this.lblsenha = new System.Windows.Forms.Label();
            this.lblNomeLoja = new System.Windows.Forms.Label();
            this.lblCNPJ = new System.Windows.Forms.Label();
            this.btnMostraSenha = new System.Windows.Forms.Button();
            this.mtxtCNPJ = new System.Windows.Forms.MaskedTextBox();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnProximo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picLoja)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // picLoja
            // 
            this.picLoja.Location = new System.Drawing.Point(574, 41);
            this.picLoja.Name = "picLoja";
            this.picLoja.Size = new System.Drawing.Size(416, 245);
            this.picLoja.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLoja.TabIndex = 34;
            this.picLoja.TabStop = false;
            this.picLoja.Click += new System.EventHandler(this.picLoja_Click);
            // 
            // btnSelecImagem
            // 
            this.btnSelecImagem.Location = new System.Drawing.Point(996, 117);
            this.btnSelecImagem.Name = "btnSelecImagem";
            this.btnSelecImagem.Size = new System.Drawing.Size(75, 54);
            this.btnSelecImagem.TabIndex = 33;
            this.btnSelecImagem.Text = "Selecione a Imagem";
            this.btnSelecImagem.UseVisualStyleBackColor = true;
            this.btnSelecImagem.Click += new System.EventHandler(this.btnSelecImagem_Click);
            // 
            // btnCadastra
            // 
            this.btnCadastra.Location = new System.Drawing.Point(805, 422);
            this.btnCadastra.Name = "btnCadastra";
            this.btnCadastra.Size = new System.Drawing.Size(75, 54);
            this.btnCadastra.TabIndex = 31;
            this.btnCadastra.Text = "Cadastra";
            this.btnCadastra.UseVisualStyleBackColor = true;
            this.btnCadastra.Visible = false;
            this.btnCadastra.Click += new System.EventHandler(this.btnCadastra_Click);
            // 
            // txtCep
            // 
            this.txtCep.Location = new System.Drawing.Point(457, 47);
            this.txtCep.Name = "txtCep";
            this.txtCep.Size = new System.Drawing.Size(157, 20);
            this.txtCep.TabIndex = 29;
            this.txtCep.TextChanged += new System.EventHandler(this.txtCep_TextChanged);
            // 
            // txtComplemento
            // 
            this.txtComplemento.Location = new System.Drawing.Point(457, 21);
            this.txtComplemento.Name = "txtComplemento";
            this.txtComplemento.Size = new System.Drawing.Size(157, 20);
            this.txtComplemento.TabIndex = 28;
            // 
            // txtRepSenha
            // 
            this.txtRepSenha.Location = new System.Drawing.Point(641, 358);
            this.txtRepSenha.Name = "txtRepSenha";
            this.txtRepSenha.PasswordChar = '*';
            this.txtRepSenha.Size = new System.Drawing.Size(157, 20);
            this.txtRepSenha.TabIndex = 27;
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(109, 81);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(157, 20);
            this.txtBairro.TabIndex = 26;
            this.txtBairro.TextChanged += new System.EventHandler(this.txtBairro_TextChanged);
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(375, 355);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(157, 20);
            this.txtSenha.TabIndex = 25;
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(109, 50);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(157, 20);
            this.txtNumero.TabIndex = 23;
            // 
            // txtNomeLoja
            // 
            this.txtNomeLoja.Location = new System.Drawing.Point(411, 254);
            this.txtNomeLoja.Name = "txtNomeLoja";
            this.txtNomeLoja.Size = new System.Drawing.Size(157, 20);
            this.txtNomeLoja.TabIndex = 22;
            // 
            // txtRua
            // 
            this.txtRua.Location = new System.Drawing.Point(109, 21);
            this.txtRua.Name = "txtRua";
            this.txtRua.Size = new System.Drawing.Size(157, 20);
            this.txtRua.TabIndex = 21;
            this.txtRua.TextChanged += new System.EventHandler(this.txtRua_TextChanged);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(641, 332);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(157, 20);
            this.txtTelefone.TabIndex = 20;
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(641, 303);
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(157, 20);
            this.txtCelular.TabIndex = 30;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(375, 329);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(157, 20);
            this.txtEmail.TabIndex = 19;
            // 
            // lblimagem
            // 
            this.lblimagem.AutoSize = true;
            this.lblimagem.Location = new System.Drawing.Point(571, 8);
            this.lblimagem.Name = "lblimagem";
            this.lblimagem.Size = new System.Drawing.Size(155, 26);
            this.lblimagem.TabIndex = 16;
            this.lblimagem.Text = "Coloque a imagem da sua Loja:\r\n\r\n";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(394, 73);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(43, 13);
            this.lblEstado.TabIndex = 15;
            this.lblEstado.Text = "Estado:";
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Location = new System.Drawing.Point(583, 335);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(52, 13);
            this.lblTelefone.TabIndex = 14;
            this.lblTelefone.Text = "Telefone:";
            // 
            // lblCelular
            // 
            this.lblCelular.AutoSize = true;
            this.lblCelular.Location = new System.Drawing.Point(593, 306);
            this.lblCelular.Name = "lblCelular";
            this.lblCelular.Size = new System.Drawing.Size(42, 13);
            this.lblCelular.TabIndex = 13;
            this.lblCelular.Text = "Celular:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(320, 329);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 12;
            this.lblEmail.Text = "Email:";
            // 
            // lblCep
            // 
            this.lblCep.AutoSize = true;
            this.lblCep.Location = new System.Drawing.Point(408, 47);
            this.lblCep.Name = "lblCep";
            this.lblCep.Size = new System.Drawing.Size(29, 13);
            this.lblCep.TabIndex = 11;
            this.lblCep.Text = "Cep:\r\n";
            // 
            // lblComplemento
            // 
            this.lblComplemento.AutoSize = true;
            this.lblComplemento.Location = new System.Drawing.Point(315, 24);
            this.lblComplemento.Name = "lblComplemento";
            this.lblComplemento.Size = new System.Drawing.Size(122, 13);
            this.lblComplemento.TabIndex = 10;
            this.lblComplemento.Text = "Complemento(Opcional):";
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.Location = new System.Drawing.Point(52, 87);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(37, 13);
            this.lblBairro.TabIndex = 9;
            this.lblBairro.Text = "Bairro:";
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Location = new System.Drawing.Point(42, 52);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(47, 13);
            this.lblNum.TabIndex = 8;
            this.lblNum.Text = "Número:";
            // 
            // lblRua
            // 
            this.lblRua.AutoSize = true;
            this.lblRua.Location = new System.Drawing.Point(59, 21);
            this.lblRua.Name = "lblRua";
            this.lblRua.Size = new System.Drawing.Size(30, 13);
            this.lblRua.TabIndex = 7;
            this.lblRua.Text = "Rua:";
            // 
            // lblRepitaSenha
            // 
            this.lblRepitaSenha.AutoSize = true;
            this.lblRepitaSenha.Location = new System.Drawing.Point(551, 361);
            this.lblRepitaSenha.Name = "lblRepitaSenha";
            this.lblRepitaSenha.Size = new System.Drawing.Size(84, 13);
            this.lblRepitaSenha.TabIndex = 6;
            this.lblRepitaSenha.Text = "Repita a Senha:";
            // 
            // lblsenha
            // 
            this.lblsenha.AutoSize = true;
            this.lblsenha.Location = new System.Drawing.Point(279, 358);
            this.lblsenha.Name = "lblsenha";
            this.lblsenha.Size = new System.Drawing.Size(76, 13);
            this.lblsenha.TabIndex = 5;
            this.lblsenha.Text = "Insira a senha:";
            // 
            // lblNomeLoja
            // 
            this.lblNomeLoja.AutoSize = true;
            this.lblNomeLoja.Location = new System.Drawing.Point(330, 257);
            this.lblNomeLoja.Name = "lblNomeLoja";
            this.lblNomeLoja.Size = new System.Drawing.Size(61, 13);
            this.lblNomeLoja.TabIndex = 17;
            this.lblNomeLoja.Text = "Nome Loja:";
            // 
            // lblCNPJ
            // 
            this.lblCNPJ.AutoSize = true;
            this.lblCNPJ.Location = new System.Drawing.Point(280, 303);
            this.lblCNPJ.Name = "lblCNPJ";
            this.lblCNPJ.Size = new System.Drawing.Size(75, 13);
            this.lblCNPJ.TabIndex = 4;
            this.lblCNPJ.Text = "CNPJ da Loja:";
            // 
            // btnMostraSenha
            // 
            this.btnMostraSenha.Location = new System.Drawing.Point(832, 327);
            this.btnMostraSenha.Name = "btnMostraSenha";
            this.btnMostraSenha.Size = new System.Drawing.Size(91, 44);
            this.btnMostraSenha.TabIndex = 35;
            this.btnMostraSenha.Text = "Mostrar Senha";
            this.btnMostraSenha.UseVisualStyleBackColor = true;
            this.btnMostraSenha.Click += new System.EventHandler(this.btnMostraSenha_Click);
            // 
            // mtxtCNPJ
            // 
            this.mtxtCNPJ.Location = new System.Drawing.Point(375, 303);
            this.mtxtCNPJ.Mask = "00.000.000/0000-00";
            this.mtxtCNPJ.Name = "mtxtCNPJ";
            this.mtxtCNPJ.Size = new System.Drawing.Size(157, 20);
            this.mtxtCNPJ.TabIndex = 37;
            this.mtxtCNPJ.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtxtCNPJ_MaskInputRejected);
            // 
            // cmbEstado
            // 
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Location = new System.Drawing.Point(457, 73);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(157, 21);
            this.cmbEstado.TabIndex = 38;
            this.cmbEstado.SelectedIndexChanged += new System.EventHandler(this.cmbEstado_SelectedIndexChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtNumero);
            this.panel1.Controls.Add(this.cmbEstado);
            this.panel1.Controls.Add(this.lblRua);
            this.panel1.Controls.Add(this.lblNum);
            this.panel1.Controls.Add(this.lblBairro);
            this.panel1.Controls.Add(this.lblComplemento);
            this.panel1.Controls.Add(this.lblCep);
            this.panel1.Controls.Add(this.lblEstado);
            this.panel1.Controls.Add(this.txtCep);
            this.panel1.Controls.Add(this.txtRua);
            this.panel1.Controls.Add(this.txtComplemento);
            this.panel1.Controls.Add(this.txtBairro);
            this.panel1.Location = new System.Drawing.Point(193, 280);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(617, 126);
            this.panel1.TabIndex = 39;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnProximo
            // 
            this.btnProximo.Location = new System.Drawing.Point(805, 422);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(75, 54);
            this.btnProximo.TabIndex = 40;
            this.btnProximo.Text = "Próximo";
            this.btnProximo.UseVisualStyleBackColor = true;
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // CadastraLoja1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(64)))), ((int)(((byte)(58)))));
            this.ClientSize = new System.Drawing.Size(1185, 680);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mtxtCNPJ);
            this.Controls.Add(this.btnMostraSenha);
            this.Controls.Add(this.picLoja);
            this.Controls.Add(this.btnSelecImagem);
            this.Controls.Add(this.btnCadastra);
            this.Controls.Add(this.txtRepSenha);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.txtNomeLoja);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblimagem);
            this.Controls.Add(this.lblTelefone);
            this.Controls.Add(this.lblCelular);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblRepitaSenha);
            this.Controls.Add(this.lblsenha);
            this.Controls.Add(this.lblNomeLoja);
            this.Controls.Add(this.lblCNPJ);
            this.Name = "CadastraLoja1";
            this.Text = "CadastraLoja1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CadastraLoja1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLoja)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picLoja;
        private System.Windows.Forms.Button btnSelecImagem;
        private System.Windows.Forms.Button btnCadastra;
        private System.Windows.Forms.TextBox txtCep;
        private System.Windows.Forms.TextBox txtComplemento;
        private System.Windows.Forms.TextBox txtRepSenha;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.TextBox txtNomeLoja;
        private System.Windows.Forms.TextBox txtRua;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.TextBox txtCelular;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblimagem;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblCelular;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblCep;
        private System.Windows.Forms.Label lblComplemento;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.Label lblRua;
        private System.Windows.Forms.Label lblRepitaSenha;
        private System.Windows.Forms.Label lblsenha;
        private System.Windows.Forms.Label lblNomeLoja;
        private System.Windows.Forms.Label lblCNPJ;
        private System.Windows.Forms.Button btnMostraSenha;
        private System.Windows.Forms.MaskedTextBox mtxtCNPJ;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnProximo;
    }
}